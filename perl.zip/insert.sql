INSERT INTO cds (cdinterpret, cdtitle, price, location)
  VALUES ('Beverley Craven','Love Scenes',9.99,'Regal');
INSERT INTO cds (cdinterpret, cdtitle, price, location)
  VALUES ('Katie Melua','Call of the Search',11.97,'Player');
INSERT INTO cds (cdinterpret, cdtitle, price, location)
  VALUES ('2raumwohnung','Kommt zusammen',16.99,'Regal');
INSERT INTO cds (cdinterpret, cdtitle, price, location)
  VALUES ('R.E.M.','Automatic for the People',13.99,'Regal');
INSERT INTO cds (cdinterpret, cdtitle, price, location)
  VALUES ('Mike Oldfield','Voyager',12.99,'Regal');
