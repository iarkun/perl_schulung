#! /usr/bin/perl

use strict;
use warnings;

if (@ARGV) {
  print "Es wurden Parameter auf der Kommandozeile angegeben\n";
  printf "  %s\n", $_ foreach @ARGV;
}
