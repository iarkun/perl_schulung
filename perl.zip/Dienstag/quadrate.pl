#! /usr/bin/perl

use strict;
use warnings;

my @liste = (1,3,5,7,9);

my @quadrate;
# Ziel: In @quadrate stehen die Quadratzahlen von @liste

# push(@quadrate, $_*$_) foreach @liste;

#foreach (@liste) {
#  push @quadrate, $_*$_;
#}

# my $var;
# my $quad;
# foreach $var (@liste) {
#   $quad = $var * $var;
#   push @quadrate, $quad;
#   printf "Zahl %s, Quadrat %s\n", $var, $quad;
# }

# Achtung $_ darf hier nicht als Index verwendet werden
$quadrate[$_] = $_*$_ foreach @liste;

printf "%d\n", $_ foreach @quadrate;

