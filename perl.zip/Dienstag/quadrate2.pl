#! /usr/bin/perl

use strict;
use warnings;

# Referenz auf Array
my $liste = [1,3,5,7,9];

my $quadrate;
# Ziel: In @quadrate stehen die Quadratzahlen von @liste

push(@$quadrate, $_*$_) foreach @$liste;

printf "%d\n", $_ foreach @$quadrate;

