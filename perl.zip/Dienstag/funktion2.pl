#! /usr/bin/perl

use strict;
use warnings;

# Alle Parameter werden in @_ zur Verfuegung gestellt
sub hallo
{
  my $name = $_[0];
  print "Hallo $name\n";
}

hallo('Thomas');
hallo 'Michael';	# Klammern duerfen weggelassen werden, wenn Funktionsaufruf klar ist.

