#! /usr/bin/perl

use strict;
use warnings;

# Alle Parameter werden in @_ zur Verfuegung gestellt
sub hallo
{
  my $name = $_[0];
  print "Hallo $name\n";
  printf "# Anzahl Parameter: %d\n", scalar(@_);
}

sub gruesse
{
  print "Hallo $_\n" foreach @_;
}

hallo('Thomas', 'Klaus', 'Hugo');
hallo 'Michael';	# Klammern duerfen weggelassen werden, wenn Funktionsaufruf klar ist.

gruesse('Thomas', 'Klaus', 'Hugo');
