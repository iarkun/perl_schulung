#! /usr/bin/perl

use strict;
use warnings;

sub sum
{
  my $a = shift(@_);
  my $b = shift;   # kein Array angegeben --> @_ wird automatisch verwendet
  return $a + $b;
}

printf "Summe von 3 und 7: %d\n", sum(3,7);

