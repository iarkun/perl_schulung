#! /usr/bin/perl

use strict;
use warnings;

sub print_service_texts
{
  my $path = shift;

  open my $fh, '<', $path or die "Kann Datei nicht oeffnen\n";
  while (my $line = <$fh>) {
    chomp $line;
    #next unless $line;   # Leerzeilen ignorieren
    #next if substr($line,0,1) eq "#";  # Kommentarzeilen ignorieren
    #next unless index($line, "#");     # Kommentarzeilen ignorieren
    #next if $line =~ m/^#/;  # ^=Zeilenanfang, #=#
    next unless $line =~ m/^	# Zeilenanfang
    		 [^\#]	# Kein # am Zeilenanfang, sonst jedes Zeichen erlaubt
		 [^\#]*	# Dann beliebig viele Nicht-#-Zeichen
		 	# Man kann auch anstelle der beiden Zeilen ueber dieser
			# [^\#]+ schreiben, also Mindestens ein Nicht-#-Zeichen
			# Im Prinzip aber beliebig viele
		 \#	# Dann genau ein #-Zeichen
		 \s*	# Gefolgt von beliebig vielen Leerzeichen
		 (.*)	# Gefolgt von beliebig vielen beliebigen Zeichen
		 	# Wegen Gruppierung () in $1 gespeichert
		 $	# ... bis zum Zeilenende
		 /x;

    #^[^#].*?#\s*(.*)$ 
    printf "%s\n", $1;
  }
  close($fh);
}

print_service_texts("/etc/services");
