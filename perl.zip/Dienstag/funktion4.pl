#! /usr/bin/perl

use strict;
use warnings;

sub sum
{
  my $a = $_[0];
  my $b = $_[1];
  return $a + $b;
}

printf "Summe von 3 und 7: %d\n", sum(3,7);

