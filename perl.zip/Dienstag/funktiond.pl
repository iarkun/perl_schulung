#! /usr/bin/perl

use strict;
use warnings;

sub in_array
{
  my $suchwert = shift;
  foreach (@{shift @_}) {	# Durch Original-Array iterieren
    return 1 if $suchwert == $_;
  }
  return 0;
}

my @liste = (1,3,4,5,6,8,10);
my $zahl = 1;

if (in_array($zahl, \@liste)) {
  print "Zahl kommt in Liste vor\n";
} else {
  print "Zahl kommt NICHT in Liste vor\n";
}
