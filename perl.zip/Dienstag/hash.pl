#! /usr/bin/perl

use strict;
use warnings;

my %hash;
$hash{'E'} = "Essen";
$hash{'B'} = "Berlin";

printf "Kennzeichen B fuer %s\n", $hash{'B'};

printf "Key %s, value %s\n", $_, $hash{$_} foreach keys %hash;
