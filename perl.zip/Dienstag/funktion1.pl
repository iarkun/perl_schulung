#! /usr/bin/perl

use strict;
use warnings;

sub hallo
{
  print "Hallo\n";
}

hallo();
hallo;	# Klammern duerfen weggelassen werden, wenn Funktionsaufruf klar ist.

