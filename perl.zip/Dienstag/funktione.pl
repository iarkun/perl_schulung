#! /usr/bin/perl

use strict;
use warnings;

sub in_array
{
  my $suchwert = shift;
  foreach (@{shift @_}) {	# Durch Original-Array iterieren
    return 1 if $suchwert == $_;
  }
  return 0;
}

my @liste = (1,3,4,5,6,8,10);
# Programm mit Fehlermeldung verlassen, falls keine Parameter angegeben
die "Kein Parameter angegeben\n" if scalar @ARGV == 0;
die "Kein Parameter angegeben\n" unless @ARGV;
# Suchzahl aus der Parameterliste lesen
my $zahl = $ARGV[0];

if (in_array($zahl, \@liste)) {
  print "Zahl kommt in Liste vor\n";
} else {
  print "Zahl kommt NICHT in Liste vor\n";
}
