#! /usr/bin/perl

use strict;
use warnings;

my @lines = <DATA>;

print $_ foreach
    map { join ';', @$_ }
    sort { $a->[1] cmp $b->[1] }
    map { [split /;/, $_] }
    @lines;

__DATA__
Peter; Bauer; Hohenufer 17; 31151
Hans; Meiser; Doffenweg 1; 30989
Urs; Müller; Schnellweg 8; 30166
Urs; Brüller; Ladenstrasse 4; 30166
Urs; Aamann; Münzgasse 56; 80782
Urs; Amann; Holzweg 17; 40555
