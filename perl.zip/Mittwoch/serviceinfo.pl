#! /usr/bin/perl

use strict;
use warnings;

sub print_service_texts
{
  my $path = shift;

  open my $fh, '<', $path or die "Kann Datei nicht oeffnen\n";
  while (<$fh>) {
    chomp;
    #next unless $line;   # Leerzeilen ignorieren
    #next if substr($line,0,1) eq "#";  # Kommentarzeilen ignorieren
    #next unless index($line, "#");     # Kommentarzeilen ignorieren
    #next if $line =~ m/^#/;  # ^=Zeilenanfang, #=#
    # [^\s|^#] # keine leerzeichen, keine Raute, kein Caret, kein Pipe

    next unless /^		# Ausdruck beginnt am Zeilenanfang
    				#     sonst wuerde irgendwo in der Zeile...
    		([^\s\#]+)	# mindestens 1 nicht-Space-Zeichen
    				#     und Kommentarzeichen
		\s+		# mindestens 1 Whitespace (Space, Tab)
		(\d+)		# mindestens 1 Ziffer, die Portnummer
		\/		# Schraegstrich
		(\S+)		# mindestens 1 Nicht-Whitespace-Zeichen
#		(tcp|udp)	# Alternativ, nur tcp oder udp matchen
		\s+		# mindestens 1 Whitespace
		([^\#]*?\S)	# mindestens 1 Nicht-#-Zeichen, und...
				#   das letzte Zeichen darf kein Space sein
		\s*		# ueberzaehlige Whitespace-Zeichen
		(\#\s*(.+)|$)	# Kommentarzeichen, beliebig viele Whitespace
				#    gefolgt von Zeichen...
				# ODER direkt ein Zeilenumbruch
    		/x;
    # $6 ist nur manchmal definiert, daher bei der Ausgabe
    #  auf undef als Wert achten
    printf "%s %d(%s) [%s]%s\n", $1, $2, $3, $4,
           defined $6 ? ' {'.$6.'}' : '';
  }
  close($fh);
}

print_service_texts("/etc/services");
