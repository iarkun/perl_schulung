#! /usr/bin/perl

use strict;
use warnings;
use Data::Dumper;

sub userlist
{
  my @liste;
  my %userinfo;
  # Oeffnet einen Programmaufruf zum Lesen mit Diamant-Operator
  open my $fh, '-|', 'getent passwd' or die "Kann Programm nicht ausfuehren";
  while (<$fh>) {
    chomp;
    my @info = split /:/;
    %userinfo = ('username' => $info[0],
    		 'uid' => $info[2],
    		 'gid' => $info[3],
		 'realname' => $info[4],
		 'homedir' => $info[5],
		 'shell' => $info[6]);
    push @liste, \%userinfo;
  }
  close $fh;
  return @liste;
}

my @users = userlist();
print Dumper \@users;
printf "%20s %d\n", $_->{'username'}, $_->{'uid'}
    foreach
    # Sortierung: Case-insensitive nach Username
    # sort { lc($a->{'username'}) cmp lc($b->{'username'}) }
    # Sortierung: Numerisch nach UID
    sort { $a->{'uid'} <=> $b->{'uid'} }
    @users;
