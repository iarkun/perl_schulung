#! /usr/bin/perl

use strict;
use warnings;

sub userlist
{
  my @liste;
  # Oeffnet einen Programmaufruf zum Lesen mit Diamant-Operator
  open my $fh, '-|', 'getent passwd' or die "Kann Programm nicht ausfuehren";
  while (<$fh>) {
    chomp;
    my @info = split /:/;
    push @liste, $info[0];
  }
  close $fh;
  return @liste;
}

my @users = userlist();
printf "%s\n", $_ foreach sort { lc($a) cmp lc($b) } @users;
