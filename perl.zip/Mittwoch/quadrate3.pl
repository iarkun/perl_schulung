#! /usr/bin/perl

use strict;
use warnings;

my @liste = (1,3,5,7,9);
my @quadrate = map { $_*$_ } @liste;

printf "%d\n", $_ foreach @quadrate;

