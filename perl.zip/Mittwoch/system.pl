#! /usr/bin/perl

use strict;
use warnings;

my $cmd = "ssh nutzer12\@notebook12 who";
system $cmd;
