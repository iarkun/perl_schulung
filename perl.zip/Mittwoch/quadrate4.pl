#! /usr/bin/perl

use strict;
use warnings;

my @liste = (1,3,5,7,9);

printf "%d\n", $_ foreach map { $_*$_ } @liste;

