#! /usr/bin/perl

use strict;
use warnings;

sub userlist
{
  # Oeffnet einen Programmaufruf zum Lesen mit Diamant-Operator
  open my $fh, '-|', 'getent passwd' or die "Kann Programm nicht ausfuehren";
  while (<$fh>) {
    chomp;
    printf "%s\n", (split /:/)[0];
  }
  close $fh;
}

userlist;
