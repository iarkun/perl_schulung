#! /usr/bin/perl

use strict;
use warnings;
use LWP::UserAgent;

sub today_german
{
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  return sprintf('%02d.%02d.%d', $mday, $mon+1, $year+1900);
}

sub read_page
{
  my $url = shift;
  my $ua = LWP::UserAgent->new;
  #$ua->agent('Wget/1.0.10');
  $ua->agent('Hurga');

  my $response = $ua->get($url);

  if ($response->is_success) {
    return $response->decoded_content;
  } else {
    # Fehler-Informationen $response->status_line
    return undef;
  }
}

sub parse_page
{
  my $content = shift;
  my @liste;
  # $content an Zeilenumbruechen auftrennen, $_ enthaelt jeweils 1 Zeile
  foreach (split /\n/, $content) {
    next unless m!<div class="box_adress"><h2>([^<]+)</h2>!;
    push @liste, $1;	# $1 aus der Gruppierung im Regex
  }
  return @liste;
}

# Aktuelles Datum berechnen und verwenden
my $today = today_german;
my $timestamp = time;
my $url = qq{http://www.aponet.de/service/notdienstapotheke-finden/suchergebnis/$today/55469%2BSimmern%252FHunsr%25C3%25BCck/-/50.html?as=0};
my $page = read_page $url;
print "Seite geladen\n" if $page;
die "Seite konnte nicht geladen werden\n" unless $page;
# print $page;

my @notdienste = parse_page $page;
my $nr=0;
printf "%d. %s\n", ++$nr, $_ foreach @notdienste;
