#! /usr/bin/perl

use strict;
use warnings;
use LWP::UserAgent;

sub today_german
{
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  return sprintf('%02d.%02d.%d', $mday, $mon+1, $year+1900);
}

sub read_page
{
  my $url = shift;
  my $ua = LWP::UserAgent->new;

  my $response = $ua->get($url);

  if ($response->is_success) {
    return $response->decoded_content;
  } else {
    # Fehler-Informationen $response->status_line
    return undef;
  }
}

# Aktuelles Datum berechnen und verwenden
my $today = today_german;
my $url = qq{http://www.lak-rlp.de/notdienstportal/schnellsuche/?location=55469&date=$today};
my $page = read_page $url;
print "Seite geladen\n" if $page;
die "Seite konnte nicht geladen werden\n" unless $page;
#print $page;
