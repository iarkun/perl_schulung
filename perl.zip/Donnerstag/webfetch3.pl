#! /usr/bin/perl

use strict;
use warnings;
use LWP::UserAgent;

sub today_german
{
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
  return sprintf('%02d.%02d.%d', $mday, $mon+1, $year+1900);
}

sub read_page
{
  my $url = shift;
  my $ua = LWP::UserAgent->new;
  $ua->default_header('Referer', 'http://www.lak-rlp.de/notdienstportal/schnellsuche/?location=55469&date=04.12.2015');

  my $response = $ua->get($url);

  if ($response->is_success) {
    return $response->decoded_content;
  } else {
    # Fehler-Informationen $response->status_line
    return undef;
  }
}

# Aktuelles Datum berechnen und verwenden
my $today = today_german;
my $timestamp = time;
my $url = qq{http://lak-rlp.notdienst-portal.de/lakrlpportal/schnellsuche/ergebnis/jsonp?jsonp=jQuery1640033118349636188316_1449142617006&date=$timestamp&lat=49.9895078&lon=7.5462508000000525&location=55469&key=a5e1d678128ff58f4e3f76fbce5ca6aa&clientKey=619aef764f041d16245d165b8600870a&host=www.lak-rlp.de&port=&handleMaxDiff=true&_=1449143007132};
my $page = read_page $url;
print "Seite geladen\n" if $page;
die "Seite konnte nicht geladen werden\n" unless $page;
print $page;
