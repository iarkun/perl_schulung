#! /usr/bin/perl

use strict;
use warnings;

die "Keine Dateien angegeben\n" unless @ARGV;

foreach my $fname (@ARGV) {
  # Vor der automatischen Verarbeitung Editor starten
  print "Starte Editor...\n";
  my $cmd = sprintf("editor %s", $fname);
  system $cmd;
  print "Verarbeiten der Datei...\n";
}
