#! /usr/bin/perl

use strict;
use warnings;

sub filelist
{
  my $dir = shift;
  opendir(my $dh, $dir);
  #<falsch># my $dh = opendir $dir;
  my @liste;
  while ($_ = readdir $dh) {
    next if /^\.{1,2}$/;
    push @liste, $_;
  }
  closedir $dh;
  return @liste;
}

my @list = filelist '.';
printf "%s\n", $_ foreach @list;
