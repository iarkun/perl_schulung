#! /usr/bin/perl

use strict;
use warnings;

# Harte Variante...
#BEGIN {
#  unshift @INC, '/home/nutzer24/Donnerstag';
#}
# use lib '/home/nutzer24/Donnerstag';
# Alternativ in der Shell (.bashrc) setzen:
# PERL5LIB=/home/nutzer24/Donnerstag; export PERL5LIB

print "@INC\n";
use MyUtils;
use MyUtils qw/filelist/;

printf "Heute ist %s\n", today_german;

my @list = filelist '../Mittwoch';
