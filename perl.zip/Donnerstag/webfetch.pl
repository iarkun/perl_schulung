#! /usr/bin/perl

use strict;
use warnings;
use LWP::UserAgent;

sub read_page
{
  my $url = shift;
  my $ua = LWP::UserAgent->new;

  my $response = $ua->get($url);

  if ($response->is_success) {
    return $response->decoded_content;
  } else {
    # Fehler-Informationen $response->status_line
    return undef;
  }
}

my $url = q{http://www.lak-rlp.de/notdienstportal/schnellsuche/?location=55469&date=04.12.2015};
my $page = read_page $url;
print "Seite geladen\n" if $page;

