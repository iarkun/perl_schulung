#! /usr/bin/perl

$greeting = "Hallo";
$destination = "Welt";

# Punkt-Operator = String-Konkatenation
$text = $greeting . " " . $destination;

print $text, "!\n";
