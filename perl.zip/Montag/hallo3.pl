#! /usr/bin/perl

# Parameter werden durch Kommas getrennt
print "Hallo", " ", "Welt!", "\n";

