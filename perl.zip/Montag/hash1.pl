#! /usr/bin/perl

use strict;
use warnings;

my %hash;
%hash = ("HH" => "Hamburg",
         "B" => "Bochum");
$hash{"E"} = "Essen";
$hash{"HB"} = "Bremen";

printf "Kennzeichen E: %s\n", $hash{"E"};
printf "Kennzeichen E: %s\n", "Essen";

# Runde Klammern koennen hier weggelassen werden
printf "Kennzeichen %s => %s\n", $_, $hash{$_} foreach (sort(keys(%hash)));

# Funktion values(%hash) liefert alle Values als Array
