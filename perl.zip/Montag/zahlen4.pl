#! /usr/bin/perl

use strict;
use warnings;

my $zahl = 17;

my $wert = 0;
my $ergebnis;  # Kein Wert zugewiesen, also implizit undef
# Division by Zero vermeiden
$ergebnis = $zahl / $wert if $wert != 0;
$ergebnis = $zahl / $wert if $wert;

#$ergebnis = $zahl - 17;
print $ergebnis, "\n" if defined $ergebnis;

# Achtung: 0 entspricht logisch false, ist aber ein definierter Wert,
#   undef ist auch logisch false, aber nicht definiert
