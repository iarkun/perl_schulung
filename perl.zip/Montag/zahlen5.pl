#! /usr/bin/perl

use strict;
use warnings;

my $zahl = 17;

my $wert = 0;
# Division by Zero vermeiden
print $zahl / $wert if $wert;

