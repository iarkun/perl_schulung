#! /usr/bin/perl

use strict;
use warnings;

my @list;

@list = (10,20);
# Array-Index beginnt bei 0
print "1. Wert: ", $list[0], "\n";
$list[0] = "Regen";
print "1. Wert: ", $list [0], "\n";
print "Höchster Index: ", $#list, "\n";
print "Länge des Arrays: ", scalar @list, "\n";

# Perl verlaengert Arrays bei Bedarf automatisch mit undef als Wert
$list[4] = "Perl";
print "5. Wert: ", $list [4], "\n";
print "Höchster Index: ", $#list, "\n";
print "Länge des Arrays: ", scalar @list, "\n";

if (defined $list[3]) {
  print "4. Wert: ", $list[3], "\n";
} else {
  print "4. Wert: ", "undefiniert", "\n";
}
# Aequivalent zum Konstrukt mit Ternaerem Operator
print "4. Wert: ", defined $list[3] ? $list[3] : "undefiniert", "\n";
