#! /usr/bin/perl

use strict;
use warnings;

my $zahl = 10;	# Skalare Variable, intern eine Integer-Zahl
my $stringzahl = "20"; # Skalare Variable, intern eine Zeichenkette
print $zahl, "\n"; # Intern wird aus der Zahl eine Zeichenkette
print $stringzahl, "\n";
print $zahl * $stringzahl, "\n"; # Hier erst aus stringzahl ein Int, dann String
