#! /usr/bin/perl

use strict;
use warnings;

my @list;

print "Höchster Index: ", $#list, "\n";
print "Länge des Arrays: ", scalar @list, "\n";

# @list = (10); # Zum Testen mal aktivieren...
# Bedingung im if ist immer Skalarer Kontext, daher bedeutet @list die Laenge
print "Array hat Elemente\n" if @list;

my $len = @list;  # skalarer Kontext erzwungen
print "Array hat Elemente\n" if $len;
