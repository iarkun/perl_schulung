#! /usr/bin/perl

use strict;
use warnings;

my @liste1 = (1,2,3);
my @liste2 = (11,12,13);

# Neues Array mit Referenzen auf Arrays erstellen
my @multiliste = (\@liste1, \@liste2);

print "Laenge von multiliste: ", scalar @multiliste, "\n";

# 1. Elemente von multiliste, dann dereferenzieren und 2. Element ansprechen
print "2 = ", $multiliste[0]->[1], "\n";
$liste1[1] = 5;
print "2 = ", $multiliste[0]->[1], "\n";
