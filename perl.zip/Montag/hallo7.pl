#! /usr/bin/perl

use strict;
use warnings;  # Alternativ -w in der Perl-Kommandozeile

# mit use strict muessen Variablen vor der Benutzung deklariert werden
my $greeting;

$greeting = "Hallo";
my $destination = "Welt";

# Punkt-Operator = String-Konkatenation
my $text = $greeting . " " . $destination;

# Doppelte Deklaration, gibt dank use warnings eine Warnung aus
# my $text = "Hallo";

print $text, "!\n";

my $strich = "-" x 25;
print $strich, "\n";
