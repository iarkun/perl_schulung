#! /usr/bin/perl

use strict;
use warnings;

my @list;
push @list, "10";
push @list, "20";

print "Höchster Index: ", $#list, "\n";
print "Länge des Arrays: ", scalar @list, "\n";

my $wert = pop @list;
print "Wert $wert aus Array entfernt\n";
print "Länge des Arrays: ", scalar @list, "\n";

$wert = shift @list;
print "Wert $wert aus Array entfernt\n";
print "Länge des Arrays: ", scalar @list, "\n";

unshift @list, "Neuer Wert";
print "Länge des Arrays: ", scalar @list, "\n";

# Elemente an beliebiger Stelle Ersetzen/Loeschen: splice
