#! /usr/bin/perl

use strict;
use warnings;

my $zahl = 15;
my $wert = 4;

print "Multiplikation: ", $zahl * $wert, "\n";
print "Addition: ", $zahl + $wert, "\n";
print "Subtraktion: ", $zahl - $wert, "\n";
print "Division: ", $zahl / $wert, "\n";
print "Integer-Division: ", int($zahl / $wert), "\n";
print "Modulo: ", $zahl % $wert, "\n";

