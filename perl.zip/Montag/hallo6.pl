#! /usr/bin/perl

use strict;
use warnings;  # Alternativ -w in der Perl-Kommandozeile

$greeting = "Hallo";
$destination = "Welt";

# Punkt-Operator = String-Konkatenation
$text = $greeting . " " . $destination;

print $text, "!\n";
