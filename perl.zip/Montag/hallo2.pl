#! /usr/bin/perl

# Ausgabe in zwei Teile aufteilen, Zeilenumbruch wird nur ausgegeben, wenn explizit angefordert
print "Hallo ";
print "Welt!\n";
