#! /usr/bin/perl

use strict;
use warnings;

my $zahl = 17;

my $wert = 0;
# Division by Zero vermeiden
die "Wert darf nicht 0 sein" unless $wert;
# Programm mit Fehler beenden, es sei denn $wert entspricht logisch True
#    kann also nicht 0 sein

# Bedingung ist jetzt ueberfluessig
print $zahl / $wert if $wert;

