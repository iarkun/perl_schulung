#! /usr/bin/perl

use strict;
use warnings;

my @liste1 = (1,2,3);
my @liste2 = (11,12,13);

# Neues Array mit allen Elementen der einzelnen Arrays
my @multiliste = (@liste1, @liste2);

print "Laenge von multiliste: ", scalar @multiliste, "\n";
print "@multiliste\n";

# Wenn keine Schleifenvariable angegeben wird, nimmt Perl $_
print $_, "\n" foreach @multiliste;
