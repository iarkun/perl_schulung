#! /usr/bin/perl

$greeting = "Hallo";
$destination = "Welt";

$destination = "Essen";

print $greeting, " ", $destination, "!\n";
